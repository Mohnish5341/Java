package opps;
//Pure abstraction
abstract class Animal1{   //abstract class is just a concept. it can't be use
	abstract void walk();
	public void eat() {
		System.out.println("Animal Eats");
	}
	Animal1(){
		System.out.println("You are creating a new Animal");
	}
}
class Horse1 extends Animal1{
	public void walk() {
		System.out.println("Walk on 4 legs");
	}
	Horse1(){
		System.out.println("You created the Animal Horse");
	}
}
class Chicken1 extends Animal1{
	public void walk() {
		System.out.println("Walk on 2 legs");
	}
}

public class OOPS5 {

}
