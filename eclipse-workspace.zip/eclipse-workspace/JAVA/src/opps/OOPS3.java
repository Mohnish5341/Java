package opps;
/*
Single level inheritance
Area method is inherited by Triangle.
*/
/*
Multy level inheritance
Area method is inherited by Triangle then from Triangle area method is inherited by Equilateral Triangle.
*/
/*
Hierarchical level inheritance
Area method is inherited by Triangle then from Triangle area method is inherited by Equilateral Triangle.
Area method is inherited by Circle
*/
class Shape{
	String color;
	public void area() {
		System.out.println("Display area");
	}
}
class Triangle extends Shape{
	public void area(int l, int h) {
    System.out.println(color+" "+(l*h)/2);
    }
}
class EquilateralTriangle extends Triangle{
	public void area(int l) {
    System.out.println(color+" "+(l*l)/2);
	}
}
class Circle extends Shape{
	public void area(int r) {
    System.out.println(color+" "+22/7*r*r);
    }
}
public class OOPS3 {
public static void main(String[] args) {
	//Shape
	Shape ob1=new Shape();
	ob1.area();
	//Triangle
	Triangle ob2=new Triangle();
	ob2.color = "Red";
	ob2.area(8,5);
	//Equilateral Triangle
	EquilateralTriangle ob3=new EquilateralTriangle();
	ob3.color = "Blue";
	ob3.area(8);
	//Circle
	Circle ob4=new Circle();
	ob4.color = "Green";
	ob4.area(6);
    }
}
