package opps;

class Pen{
	String color;
	String Type;
	
	public void write() {
		System.out.println("Writhing Something");
	}
	public void printcolor() {
		System.out.println(this.color);//this.atribute define that which object property will be called
	}
}

public class OOPS {
	public static void main(String[] args) {
		Pen ob1=new Pen();
		Pen ob2=new Pen();
		ob1.color = "Red";
		ob1.Type = "Gell";
		ob2.color = "Black";
		ob1.write();
		ob2.printcolor();
		ob1.printcolor();

	}

}
