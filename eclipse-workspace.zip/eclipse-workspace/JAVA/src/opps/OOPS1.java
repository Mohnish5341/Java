package opps;

class Student{
	String name;
	int age;
	public void printInfo() {
		System.out.println(this.name);
		System.out.println(this.age);
	}
	//constructors
	//CONSTRUCTORS NO RETURNS, NO RETURN TYPE, NO VOID ALLOWED,
	Student(){//non parameterized constructors
		System.out.println("Constructor called");
	}
    Student(String name,int age){//parameterized constructors
		this.name = name;
		this.age = age;
	}
    Student(Student s4){//copy constructors
		this.name = s4.name;
		this.age = s4.age;
	}
	
}

public class OOPS1 {
	public static void main(String[] args) {	
		
		//parameterized constructor
		Student s1 = new Student("Mohnish",21);//constructor is called when object is created
	    s1.printInfo();
	    //Non parameterized constructor
	    Student s2 = new Student();
	    //copy constructor
	    Student s3 = new Student("Krishna",23);
	    Student s4 = new Student(s3);
	    s4.printInfo();
	}
}
