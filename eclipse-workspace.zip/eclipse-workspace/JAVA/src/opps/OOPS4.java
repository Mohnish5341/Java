package opps;
//Impure abstraction
/*
Note: 
1.it is by default public , static , final
2.all method by default public & abstract
3.it support multiple inheritance
4.A class that implements an interface must implement all the methods declared in the interface
*/
interface Animal{   //abstract class is just a concept. it can't be use
	public void walk();
}
interface Hervivore{
	public void V_eat();
}
class Horse implements Animal,Hervivore{
	public void walk() {
		System.out.println("Walk on 4 legs");
	}
	Horse(){
		System.out.println("You created the Animal Horse");
	}
	public void V_eat(){
		System.out.println("I eat grass");
	}
}
class Chicken implements Animal{
	public void walk() {
		System.out.println("Walk on 2 legs");
	}
}
public class OOPS4 {
	public static void main(String[] agrs) {
		Horse horse = new Horse();//First Parent class constructor will be called then sub class
		horse.walk();
		horse.V_eat();
		Chicken chicken = new Chicken();
		chicken.walk();
	}
}
