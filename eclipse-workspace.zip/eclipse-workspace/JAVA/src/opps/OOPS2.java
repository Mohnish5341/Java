package opps;

//FOUR MAJOR TOPICS IN OPPS

//1.ABSTRACTION
//2.INHERITANCE
//3.POLYMORPHISM
//4.ENCAPSULATION

class Teacher{
	String name;
	int age;
	/*Note:
		Out of three one should be followed
		1.Argument can't be same
		2.Return Type can't be same
		3.Method Type can't be same
	*/
	public void printInfo(String name) {//FUNCTION OVERLOADING
		System.out.println(name);
	}
	public void printInfo(int age) {
		System.out.println(age);
	}
	public void printInfo(String name, int age) {
		System.out.println(name);
	}
}
public class OOPS2 {
public static void main(String[] args) {
	Teacher ob1=new Teacher();
	ob1.printInfo("Mohnish");
	ob1.printInfo(34);
	ob1.printInfo("Krishna", 34);
	
}
}
