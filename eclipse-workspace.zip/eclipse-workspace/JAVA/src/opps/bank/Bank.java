package opps.bank;
class Account{
	public String name;
	protected String email;
	private String password;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
public class Bank {
public static void main(String[] args) {
	Account account1 = new Account();
	account1.name = "Apna College";
	account1.email = "apna.college.com";
	account1.setPassword("P@ssword");
	System.out.println(account1.getPassword());
    }
}


/*
Access Modifier
 1. Public : Access through packages,class 
 2. default : Access through package and class 
 3. Protected : Access through current package, packages,sub classes
 4. Private : Access through class and getter setters

*/