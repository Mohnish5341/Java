package OPPS1;
//enum is class here and inside it it is objects
enum Size
{SMALL, MEDIUM, LARGE, EXTRALARGE}

class Test
{
	Size ob1;
	public Test(Size ob1) 
	{
		this.ob1=ob1;
	}
	public void oredePizza() 
	{
		switch(ob1) 
		{
		case SMALL:
			System.out.println("I ordered a small size pizza.");
			break;
		case MEDIUM:
			System.out.println("I ordered a medium size pizza.");
			break;
		case LARGE:
			System.out.println("I ordered a large size pizza.");
            break;
		case EXTRALARGE:
			System.out.println("I ordered a extralarge size pizza.");
			break;
		}
	}
}

//enum constructors
enum Size1 {
	   // enum constants calling the enum constructors 
	   SMALL("The size is small."),
	   MEDIUM("The size is medium."),
	   LARGE("The size is large."),
	   EXTRALARGE("The size is extra large.");
	
	   private final String pizzaSize;
	   // private enum constructor
	   private Size1(String pizzaSize) {
	      this.pizzaSize = pizzaSize;
	   }
	   public String getSize() {
	      return pizzaSize;
	   }
	}
//enum Strings
enum Size3 {
	   SMALL  {
	      // overriding toString() for SMALL
	      public String toString() {return "The size is small.";}
	          },
	   MEDIUM {
	     // overriding toString() for MEDIUM
	      public String toString() {return "The size is medium.";}
	          };
	       }

public class Enum 
{
	public static void main(String[] args)
	{
		Test ob2 = new Test(Size.EXTRALARGE);
		ob2.oredePizza();
		
		Size1 size = Size1.EXTRALARGE;
	    System.out.println(size.getSize());
	    System.out.println(size.EXTRALARGE);
	    
	    System.out.println("string value of SMALL is " + Size3.SMALL.toString());
	    System.out.println("string value of MEDIUM is " + Size3.MEDIUM.name());


	}
}
