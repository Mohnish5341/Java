package OPPS1;
//if you don't want to have multiple instances of the class then will have a concept of Singleton.
//Singleton can have only one instance means only one object.


class ABC
{
	int a=2;
	int b=3;
	int sum = a+b;
	static ABC obj =new ABC();
	        //OR
//	private static ABC obj;
    private ABC() 
    {
    	System.out.println("Constructor will invoke for only one object");
    }
    public static ABC getInstance()
    {
    	return obj;
    }
    public void getmethod() 
    {
    	System.out.println(sum);
    }
    
}
public class Singleton 
{
	public static void main(String[] args) 
	{
		//ABC obj1=new ABC();//compile time exception
		ABC obj1=ABC.getInstance();
		ABC obj2=ABC.getInstance();
		obj2.getmethod();
        //Both the references obj1 and obj2 calling the same reference i.e. obj
	}
}
