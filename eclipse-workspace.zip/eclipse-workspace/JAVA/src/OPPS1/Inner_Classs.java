package OPPS1;

class CPU
{
	double price;
	//nested class
	class Processor{
		double cores;
		String manufacturer;
		double getCache() {return 4.3;}
	}
	//nested protected class
	protected class RAM{
		double memory;
		String manufacturer;
		double getClockSpeed() {return 5.5;}
	}
}

class Car 
{
    String carName;
    String carType;
    // assign values using constructor
    public Car(String name, String type) {
        this.carName = name;
        this.carType = type;
    }
    // private method
    private String getCarName() {
        return this.carName;
    }
// inner class
    class Engine {
        String engineType;
        void setEngine() {
           // Accessing the carType property of Car
            if(Car.this.carType.equals("4WD"))
            {
                // Invoking method getCarName() of Car
            //  if(Car.this.carName.equals("Crysler")) 
                if(Car.this.getCarName().equals("Crysler")) 
                {this.engineType = "Smaller";} 
                else {this.engineType = "Bigger";}
            }
            else{this.engineType = "Bigger";}
        }
        String getEngineType()
        {return this.engineType;}
    }
}
public class Inner_Classs 
{
	public static void main(String[] args) 
	{
		CPU cpu = new CPU();
		CPU.Processor processor = cpu.new Processor();//object for inner class
		CPU.RAM ram = cpu.new RAM();//object for inner class
		System.out.println("Processor Cache = "+ processor.getCache());
		System.out.println("Ram Clock Speed = "+ram.getClockSpeed());
		
        Car car1 = new Car("Mazda", "8WD");
		Car.Engine engine = car1.new Engine();
        engine.setEngine();
        System.out.println("Engine Type for 8WD= " + engine.getEngineType());

        Car car2 = new Car("Crysler", "4WD");
        Car.Engine c2engine = car2.new Engine();
        c2engine.setEngine();
        System.out.println("Engine Type for 4WD = " + c2engine.getEngineType());
    }
}

