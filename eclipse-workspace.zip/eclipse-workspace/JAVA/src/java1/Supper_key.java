package java1;

class Parent1{
int a=66;

Parent1(){
	System.out.println("I am Parent1");
}
Parent1(String k){
	System.out.println("I am "+ k +" constructor Parent1");
}
}
class Child1 extends Parent1{
int a=50;
public void display() {
	//calling variables from parent class using super
	System.out.println("Child1 " + a);
	System.out.println("Parent " + super.a);
}
}
class Child2 extends Parent1{
	Child2(){ //non parameterized constructor will call Parent constructor 1st
		System.out.println("I am not parameterized constructor Child2");
	}
}
class Child3 extends Parent1{
	Child3(String k){ // parameterized constructor will call Parent constructor using super key word
		super(k);
		System.out.println("I am "+ k +"constructor Child3");
	}	
}
public class Supper_key {
public static void main(String[] args)
{
	Child1 c1=new Child1();
	c1.display();
	Child2 c2=new Child2();
	Child3 c3=new Child3("parameterized");
}
}
