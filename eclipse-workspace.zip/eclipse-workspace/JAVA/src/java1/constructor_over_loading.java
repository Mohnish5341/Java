package java1;

public class constructor_over_loading 
{
	String language = "python";
	constructor_over_loading()
	{
		this.language = "Java";
	}
	constructor_over_loading(String language)
	{
		this.language=language;
	}
	void conc()
	{
		System.out.println(this.language);
		//or
		System.out.println(language);
	}
	public static void main(String[] args)
	{
		constructor_over_loading ob3 = new constructor_over_loading();
		constructor_over_loading ob4 = new constructor_over_loading("C++");
		ob3.conc();
		ob4.conc();
	}
}
