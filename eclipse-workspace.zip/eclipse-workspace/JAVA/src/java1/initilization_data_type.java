package java1;

public class initilization_data_type 
{
   public static void main(String[] args)
      {
	   int a = 12;
	   int b = 5;
	   float c = a/b;
	   String d ="Mohnish";
	   boolean e = true;
	   char f = 'M';
	   double g = 33;
	   long h = 3232323232L;
	   short i = 333;
	   byte j = 44;

	   System.out.println("My Name is " + d + " I like java "+ e);
	   System.out.println("My Gender is " +f);
	   System.out.println("double "+g);
	   System.out.println("long "+h);
	   System.out.println("short "+i);
	   System.out.println("byte "+j);
	   System.out.println("A= "+a +" B= "+ b);
	   System.out.println("Addition of a+b =" +( a+b));
	   System.out.println("Subtraction of a-b =" +(a-b));
	   System.out.println("Division of a/b =" + c);
	   System.out.println("Multiplication of a/b =" + (a*b));
	   System.out.println("Modulo of a/b =" + (a%b));


	   }
}

