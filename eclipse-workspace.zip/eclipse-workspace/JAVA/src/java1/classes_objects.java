package java1;
import java.util.*;

public class classes_objects 
{
	String C = "1st Programe";
	
	public static void main(String[] args)
	{
		char Section = 'A';
		School ob1 = new School();
		Class ob2 = new Class();	
		classes_objects ob3 = new classes_objects();
		ob1.Teacher();
		ob2.Student(89);
		System.out.println(ob3.C);
		int result1 = ob1.nk();
		int result2 = ob2.sum(45, 90);
		System.out.println(result1);
		System.out.println(result2);
	}
}

class School
{  
	// Method having void will not return any value
	void Teacher()
	{String Name = "Mohnish";
	System.out.println(Name);}
	int a = 55;
	int nk() {return a;}
	
}

class Class
{
	// Method having void will not return any value
	void Student(int h)
	{String C_Name = "12th";
	System.out.println(C_Name + h);}
    int sum(int k,int l)
    {
    	int s = k + l;
    	return s;
    }
}

