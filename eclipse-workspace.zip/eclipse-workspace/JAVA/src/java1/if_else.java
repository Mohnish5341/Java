package java1;

import java.util.Scanner;

public class if_else 
{
	public static void main(String[] args) 
	{
		//if , if else
		int a = 100;
		if (a>=90)
		{
			System.out.println("Grade A ");
		}
		else if (a>=80)
		{
			System.out.println("Grade B ");
		}
		else
		{
			System.out.println(" Less than 80");
		}
		
		
		// switch-case
		
		char Grade = 'D';
		 switch (Grade)
		 {
		 case 'A':
			 System.out.println(" More than 90");
			 break;
		 case 'B':
				System.out.println(" More than 80");
				break;
		 default:
				System.out.println(" Less than 80");
				break;
		 }
		 
		 // For loop
		 for (int k=1;k<=10;)
		 {
				System.out.println("1 * "+k+ " = "+ k);
				k += 1;
		 }
		 
		 System.out.println("");

		 for (int J=2,N=1;J<=20;)
		 {
				System.out.println("2 * "+N+ " = "+ J);
				J += 2;
				N += 1;
		 }
		 
		 //for-each loop
		 
		 char[] vowels = {'a','e','i','o','u'};
		 for(int V=0; V<vowels.length; ++V)
		 {
				System.out.println("Vowels " + vowels[V]);
		 }
		 
		 String[] Friends = {"Mohnish","Jyothi","Gowcheelya","Chandana","Abhinav","Managona"};
		 for(int Busy=0; Busy<Friends.length; ++Busy)
			{
				System.out.println(" Busy Friends " + Friends[Busy]);
			}
		 
		 // While, Do While loop
		 int G = 1; 
		 while (G<=24)
		 {
			 System.out.println(" Age of Gowcheelya " + G);
			 G +=1;
		 }
		 
		 int M = 1;
		 int Y = 2002;		 
		 do 
		 {
				System.out.println("Year of Mohnish is " + M);
				++M;
				++Y;
		 }
		 while(Y <=2023);
		 
		 //inputs
		 
		 Scanner input = new Scanner(System.in);
		 float number;
		 float Sum = 0;
		 float count = -1;
		 do {
			 System.out.println("Enter You Marks to get your Percentage and Type 0 to exit");
			 number = input.nextInt();
			 Sum +=number;
			 ++count;
			 }
		 while(number > 0);
		 System.out.println("Sum "+ Sum+" count "+count);
		 System.out.println("Total Percentage" +( Sum/count)+"%");
	
	
	}
	
}
