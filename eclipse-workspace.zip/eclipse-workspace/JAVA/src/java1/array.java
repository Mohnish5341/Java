package java1;

import java.util.Arrays;

public class array 
{
	public static void main(String[] args)
	{
		String[][] a = new String[2][4];
		a[0][0]="a[0][0]";
		a[0][1]="a[0][1]";
		a[0][2]="a[0][2]";
		a[0][3]="a[0][3]";
		a[1][0]="a[1][0]";
		a[1][1]="a[1][1]";
		a[1][2]="a[1][2]";
		a[1][3]="a[1][3]";
		
		System.out.println(a[0][0] + " " + a[0][1] + " " + a[0][2] + " " + a[0][3]);
		System.out.println(a[1][0] + " " + a[1][1] + " " + a[1][2] + " " + a[1][3]);

		String[][] b = {
		        {"00","01","02"},{"10","11","12"}
		       };
        System.out.println(b[0][0] + " " + b[0][1] + " " + b[0][2]);
        System.out.println(b[1][0] + " " + b[1][1] + " " + b[1][2]);

	//Copying Arrays Using Assignment Operator
        int[] c = {1,2,3,4,5};
        int[] d = c; 
        System.out.println(d);
        for (int e:d)
        {
            System.out.print(e + ",");
        }    
        c[0] = 0;
        System.out.println(" ");
        System.out.println(d);
        for (int e:d)
        {
            System.out.print(e + ",");
        } 
        //Using Looping Construct to Copy Arrays 
        int [] source = {1, 2, 3, 4, 5, 6};
        int [] destination = new int[6];

        // iterate and copy elements from source to destination
        for (int i = 0; i < source.length; ++i) {
            destination[i] = source[i];
        }
        System.out.println();
        System.out.println(Arrays.toString(destination));
        
        //Copying Arrays Using copyOfRange() method
        int[] k = Arrays.copyOfRange(source,2,4);
        System.out.println(Arrays.toString(k));
        
        //Copying Arrays Using arraycopy() method
        int[] n1 = {2, 3, 12, 4, 12, -2}; 
        int[] n3 = new int[5];
        System.arraycopy(n1, 0, n3, 1, 3);
        System.out.println("n1 = " + Arrays.toString(n1));  
        System.out.println("n3 = " + Arrays.toString(n3));  
        
	}
	
}
