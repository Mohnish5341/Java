package java1;

public class loop 
{
	public static void main(String[] Args)
	{
		 // Prime numbers.
		 for (int q=1;q<=10;++q)
		 {
			 int count = 0;
			 for (int w=1;w<=q;++w) 
			 {
				 if (q%w==0) 
				 {
					 ++count;
				 }
			 }
			 if (count ==2)
			 {
				 System.out.println(q);
			 }
         }  
		 //Odd numbers and Even numbers
		 for (int l=1;l<=10;++l)
		 {
			 int r=2;
			 if( l%r == 0)
			 {
				 System.out.println("Even " + l);
			 }
			 else
				 System.out.println("Odd " + l);
	     }		 
		 //Odd numbers using continue
		 for (int k=1;k<=20;++k)
		 {
			 int o=2;
			 if( k%o == 0)
			 {
				 continue;
			 }
			 else
				 System.out.println("Odd " + k);
	     }	
		 // break
		 for (int h =1;h<=10;++h)
		 {
			 if(h==10)
			 {
				 break;
			 }
			 System.out.println("Use of Break "+h);
		 }
		 // Array
		 int[] Ages = {1,6,78,3,4,97,45,23,15,6,74,34};
		 for (int f=0; f<Ages.length;++f)
		 {
			 if(Ages[f]>=18)
			 {
				 System.out.println("Adults Age are: "+Ages[f]);
			 }
			 else
			 {
				 System.out.println("Chlidren Age are: "+Ages[f]);
			 }
			 
			 //initiling Array
			 
			 int Ar[] = new int[5];
			 Ar[0] = 1;
			 Ar[1] = 2;
			 Ar[2] = 3;
			 Ar[3] = 4;
			 Ar[4] = 5;
			 for (int U=0;U<Ar.length;++U) 
			 {
			 System.out.println("Array Index "+ U +" is "+Ar[U]);
			 }
		 }		 
    }
}
