package java1;

public class this_key 
{
	private int a, b;
	this_key()
	{
		this(0);
	}
	this_key(int i)
	{
		this(i,i);
	}
	this_key(int i, int j)
	{
		this.a = i;
		this.b = j;
	}
	@Override
	public String toString() {
		return "this_key [a=" + a + ", b=" + b + "]";
	}
	
	public static void main(String[] args)
	{
		this_key ob1=new this_key();
		this_key ob2=new this_key(2);
		this_key ob3=new this_key(3,5);
		System.out.println(ob1);
		System.out.println(ob2);
		System.out.println(ob3);
	}
}
