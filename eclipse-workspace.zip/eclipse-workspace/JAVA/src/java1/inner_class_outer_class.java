package java1;

public class inner_class_outer_class 
{  
	public static void main(String[] args) 
	{
	    OuterClass myOuter = new OuterClass();
	    OuterClass.InnerClass myInner = myOuter.new InnerClass();
	    System.out.println(myOuter.x + myInner.y);
	}
}
class OuterClass {
	  int x = 10;

	  class InnerClass {
	    int y = 5;
	  }
	}
