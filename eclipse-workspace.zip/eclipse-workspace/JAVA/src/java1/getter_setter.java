package java1;

class Animal
{
	private String animal;

	public String getAnimal() {
		return animal;
	}

	public void setAnimal(String animal) {
		this.animal = animal;
	}
	
}
public class getter_setter 
{
	public static void main(String[] args)
	{
		Animal ob1= new Animal();
		ob1.setAnimal("Dogs");
		System.out.println(ob1.getAnimal());
	}
}
