package java1;

class dog
{
	String d = "Dog1";
	protected void dog()
	{System.out.println("I am a "+d);}
}
//inheritance
public class access_modifiers extends dog 
{
	public static void main(String[] args)
	{
	access_modifiers ob = new access_modifiers();
	ob.dog();
	System.out.println(ob.d);
	dog ob2 = new dog();
	System.out.println(ob2.d);
	}
}
