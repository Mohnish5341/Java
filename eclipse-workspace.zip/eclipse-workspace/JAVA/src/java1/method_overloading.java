package java1;

public class method_overloading 
{
	private String formatNumber(int value) {
        return String.format("%d", value);
    }

    private String formatNumber(double value) {
        return String.format("%.3f", value);
    }

    private String formatNumber(String value) {
        return String.format("%.2f", Double.parseDouble(value));
    }
        
	public static void main(String[] args)
	{
		method_overloading ob1 = new method_overloading();
		System.out.println(ob1.formatNumber(500));
		System.out.println(ob1.formatNumber(500.434));
		System.out.println(ob1.formatNumber("500"));
	}
}
