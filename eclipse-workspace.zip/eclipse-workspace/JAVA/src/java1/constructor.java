package java1;

public class constructor 
{
	constructor(String language)
	{
		System.out.println(language);
	}
	constructor(String language,String language2)
	{
		System.out.println(language +" "+language2);
	}
	public static void main(String[] args)
	{
		constructor ob1=new constructor("Java");
		constructor ob2=new constructor("Java","Python");
		
	}
}
