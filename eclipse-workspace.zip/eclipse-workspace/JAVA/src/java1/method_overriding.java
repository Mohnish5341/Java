package java1;


abstract class Tree{
	abstract void leaf();
}
//overriding
class Mango_Tree extends Tree{
	public void leaf() {
		System.out.println("I have Green leafs");
	}
}
//overriding
class Orange_Tree extends Tree{
	public void leaf() {
		System.out.println("I have Orange leafs");
	}
}

public class method_overriding {
public static void main(String[] args) {
	Mango_Tree ob1=new Mango_Tree();
	Orange_Tree ob2=new Orange_Tree();
	ob1.leaf();
	ob2.leaf();
}
}
