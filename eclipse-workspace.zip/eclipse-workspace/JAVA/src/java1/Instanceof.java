package java1;

class raunak{}
class sonu{
} 
class bitu extends sonu{
} 
public class Instanceof {
public static void main (String[] args) {
sonu ob1=new sonu();
bitu ob2=new bitu();
raunak ob3=new raunak();

boolean k= ob1 instanceof sonu;
boolean h= ob2 instanceof sonu;
boolean j= ob3 instanceof raunak;

System.out.println(k+" "+" "+h+" "+j);
}
}
